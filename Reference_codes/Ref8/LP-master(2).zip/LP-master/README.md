# LP
Link Prediction  

Some file for Link Prediction，It include different ways to implement relative algorithm，The YeastNet.py is implemented by just myself and the Y_test.py implemented uses networkX(version 2.2) package
