from process.PreReadFile import readFile as RF
import process.LinkPrediction as LP
import networkx as nx

if __name__ == "__main__":
    SciMet_path = r"C:\Users\Tang\Desktop\data\SciMet.txt"